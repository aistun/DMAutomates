# Compilation

`dune build` dans le dossier où sont extraits les fichiers.

# Exécution

Je exécutais l'exécutable qui se trouve à cet emplacement après avoir compilé `./_build/default/main.exe`.
Le format de l'exécution est `executable fichier.typ fichier.xml type_de_la_racine`.
